package co.edu.uniquindio.statefx.stateapp.model.State;

public class Steward extends Puesto{
    private double porcentajeGanancias;
    private final double valorHoraLabor;

    public Steward() {
        this.porcentajeGanancias = porcentajeGanancias;
        this.valorHoraLabor = 6000;
    }

    @Override
    public Double calcularBonificacion(double propinas, int cantidadEmpleadosArea) {
        porcentajeGanancias = 0.2;
        return propinas*porcentajeGanancias/cantidadEmpleadosArea;
    }

    @Override
    public Double calcularSalario(double horasLaboradas) {
        return valorHoraLabor*horasLaboradas;
    }
}
