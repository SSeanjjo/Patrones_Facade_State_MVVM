package co.edu.uniquindio.statefx.stateapp.Controller;

import co.edu.uniquindio.statefx.stateapp.factory.ModelFactory;
import co.edu.uniquindio.statefx.stateapp.model.Factura;

import java.util.ArrayList;
import java.util.List;

public class ControllerState {

    ModelFactory modelFactory;

    public ControllerState() {

        modelFactory = ModelFactory.getInstance();
    }
}


    




