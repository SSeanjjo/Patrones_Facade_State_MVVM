package co.edu.uniquindio.statefx.stateapp.model.State;

public class Cocinero extends Puesto{
    private double porcentajeGanancias;
    private final double valorHoraLabor;

    public Cocinero() {
        this.porcentajeGanancias = porcentajeGanancias;
        this.valorHoraLabor = 5800;
    }

    @Override
    public Double calcularBonificacion(double propinas, int cantidadEmpleadosArea) {
        porcentajeGanancias = 0.3;
        return propinas*porcentajeGanancias/cantidadEmpleadosArea;
    }

    @Override
    public Double calcularSalario(double horasLaboradas) {
        return valorHoraLabor*horasLaboradas;
    }
}


