package co.edu.uniquindio.statefx.stateapp.ViewController;

import java.net.URL;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import co.edu.uniquindio.statefx.stateapp.Controller.ControllerState;
import co.edu.uniquindio.statefx.stateapp.model.Factura;
import co.edu.uniquindio.statefx.stateapp.model.State.Cocinero;
import co.edu.uniquindio.statefx.stateapp.model.State.Mesero;
import co.edu.uniquindio.statefx.stateapp.model.State.Puesto;
import co.edu.uniquindio.statefx.stateapp.model.State.Steward;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import static javafx.scene.input.KeyCode.R;

public class ViewControllerState {

    ControllerState controllerState;

    ArrayList<Factura> facturas = new ArrayList<>();

    Factura factura;

    private String tipoPuesto;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button btnFactura;

    @FXML
    private RadioButton estadoCocinero;

    @FXML
    private RadioButton estadoMesero;

    @FXML
    private RadioButton estadoSteward;


    @FXML
    private TextArea textAreaFactura;

    @FXML
    private TextField txtCantidadEmpleados;

    @FXML
    private TextField txtDocumento;

    @FXML
    private TextField txtFecha;

    @FXML
    private TextField txtHoras;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtValorPropinas;


    @FXML
    void onCocinero(ActionEvent event) {
        tipoPuesto = "Cocinero";
    }

    @FXML
    void onMesero(ActionEvent event) {
        tipoPuesto = "Mesero";
    }

    @FXML
    void onSteward(ActionEvent event) {
        tipoPuesto = "Steward";
    }

    @FXML
    void onCrearFactura(ActionEvent event) {

        Puesto puesto;
        if(tipoPuesto.equals("Mesero")){
            puesto = new Mesero();
        } else if(tipoPuesto.equals("Cocinero")){
            puesto = new Cocinero();
        } else {
            puesto = new Steward();

        }
        informaciónFactura(puesto);




    }

    @FXML
    void initialize() {

        controllerState = new ControllerState();
        factura = new Factura();
        limpiarCampos();

    }



    public void limpiarCampos(){
        txtNombre.setText("");
        txtDocumento.setText("");
        txtFecha.setText("");
        txtHoras.setText("");
        txtValorPropinas.setText("");
        txtCantidadEmpleados.setText("");
    }


    public void  informaciónFactura(Puesto puesto){

        double bonificacion = puesto.calcularBonificacion(obtenerCantidadDouble(txtValorPropinas),obtenerCantidadEntero(txtCantidadEmpleados));
        double salario = puesto.calcularSalario(obtenerCantidadDouble(txtHoras));

        String factura = txtFecha.getText() + "\n"+  "\n"+ " Empleado:"+ txtNombre.getText() + "\n" +" identificación: "
                + txtDocumento.getText()+ "\n" + " Cantidad horas: " + txtHoras.getText() +"\n"+ " Valor propinas: "
                + txtValorPropinas.getText()+ "\n" +"Su bonificación fue de: "+ bonificacion + "\n" + "Sueldo final: " +  salario ;




        textAreaFactura.setText(factura);






    }




    private int obtenerCantidadEntero(TextField textField) {
        try {
            return Integer.parseInt(textField.getText());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
    private double obtenerCantidadDouble(TextField textField) {
        try {
            return Double.parseDouble(textField.getText());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }






}

