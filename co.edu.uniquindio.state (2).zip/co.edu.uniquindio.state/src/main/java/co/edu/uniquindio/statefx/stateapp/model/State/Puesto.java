package co.edu.uniquindio.statefx.stateapp.model.State;

public abstract class Puesto {
    public abstract Double calcularBonificacion(double propinas, int cantidadEmpleadosArea);
    public abstract Double calcularSalario(double horasLaboradas);

    Double calcularSalarioTotal(double propinas, double salarioNormal){
        return propinas+salarioNormal;
    }
}
