package co.edu.uniquindio.statefx.stateapp.model;

import co.edu.uniquindio.statefx.stateapp.model.State.Cocinero;
import co.edu.uniquindio.statefx.stateapp.model.State.Mesero;
import co.edu.uniquindio.statefx.stateapp.model.State.Puesto;
import co.edu.uniquindio.statefx.stateapp.model.State.Steward;

public class Factura {
    private Puesto puesto;
    private String nombre;
    private String numeroIdentificacion;
    private int horasLaboradas;
    private String fecha;
    private int cantidadEmpleadosArea;
    private Double valorPropinas;

    public Factura() {
    }

    public Factura(Puesto puesto, String nombre, String numeroIdentificacion, int horasLaboradas, String fecha, int cantidadEmpleadosArea, Double valorPropinas) {
        this.puesto = puesto;
        this.nombre = nombre;
        this.numeroIdentificacion = numeroIdentificacion;
        this.horasLaboradas = horasLaboradas;
        this.fecha = fecha;
        this.cantidadEmpleadosArea = cantidadEmpleadosArea;
        this.valorPropinas = valorPropinas;
    }



    public Puesto getPuesto() {
        return puesto;
    }

    public void setPuesto(Puesto puesto) {
        this.puesto = puesto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public int getHorasLaboradas() {
        return horasLaboradas;
    }

    public void setHorasLaboradas(int horasLaboradas) {
        this.horasLaboradas = horasLaboradas;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getCantidadEmpleadosArea() {
        return cantidadEmpleadosArea;
    }

    public void setCantidadEmpleadosArea(int cantidadEmpleadosArea) {
        this.cantidadEmpleadosArea = cantidadEmpleadosArea;
    }

    public Double getValorPropinas() {
        return valorPropinas;
    }

    public void setValorPropinas(Double valorPropinas) {
        this.valorPropinas = valorPropinas;
    }
}


