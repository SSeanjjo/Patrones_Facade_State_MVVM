package co.edu.uniquindio.statefx.stateapp.factory;

import co.edu.uniquindio.statefx.stateapp.model.Factura;
import co.edu.uniquindio.statefx.stateapp.model.State.Cocinero;
import co.edu.uniquindio.statefx.stateapp.model.State.Mesero;
import co.edu.uniquindio.statefx.stateapp.model.State.Puesto;
import co.edu.uniquindio.statefx.stateapp.model.State.Steward;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class ModelFactory {

    private static ModelFactory modelFactory;
    Factura factura;
    Cocinero cocinero;
    Steward steward;
    Mesero mesero;


    ArrayList<Factura> facturas = new ArrayList<>();


    public ModelFactory() {
        factura = new Factura();


    }

    public static ModelFactory getInstance(){
        if (modelFactory == null){
            modelFactory = new ModelFactory();



        }return modelFactory;
    }










}
