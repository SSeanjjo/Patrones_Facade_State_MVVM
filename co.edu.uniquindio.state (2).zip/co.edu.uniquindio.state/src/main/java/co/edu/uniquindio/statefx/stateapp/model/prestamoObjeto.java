package co.edu.uniquindio.statefx.stateapp.model;

import co.edu.uniquindio.statefx.stateapp.model.State.Cocinero;
import co.edu.uniquindio.statefx.stateapp.model.State.Mesero;
import co.edu.uniquindio.statefx.stateapp.model.State.Puesto;
import co.edu.uniquindio.statefx.stateapp.model.State.Steward;

public class prestamoObjeto {


}
