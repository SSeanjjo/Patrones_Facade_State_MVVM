package co.edu.uniquindio.statefx.stateapp.model.State;

public class Mesero extends Puesto{
    private double porcentajeGanancias;
    private final double valorHoraLabor;


    public Mesero() {
        this.porcentajeGanancias = porcentajeGanancias;
        this.valorHoraLabor = 5600;
    }




    @Override
    public Double calcularBonificacion(double propinas, int cantidadEmpleadosArea) {
        porcentajeGanancias = 0.5;
        return propinas*porcentajeGanancias/cantidadEmpleadosArea;
    }



    @Override
    public Double calcularSalario(double horasLaboradas) {
        return horasLaboradas*valorHoraLabor;
    }
}
