module co.edu.uniquindio.statefx.stateapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;


    opens co.edu.uniquindio.statefx.stateapp to javafx.fxml;
    exports co.edu.uniquindio.statefx.stateapp;

    opens co.edu.uniquindio.statefx.stateapp.Controller;
    exports co.edu.uniquindio.statefx.stateapp.Controller;

    opens co.edu.uniquindio.statefx.stateapp.ViewController;
    exports co.edu.uniquindio.statefx.stateapp.ViewController;
}