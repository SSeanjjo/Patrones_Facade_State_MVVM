package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model;

public class ClienteComercioElectronico {




}

