package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model;

import java.util.ArrayList;

public class ComercioElectronicoFacade {

    private ProcesamientoPagos procesamientoPagos;
    private GestionInventario gestionInventario;
    private  EnvioCorreo envioCorreo;

    public ComercioElectronicoFacade() {
        this.procesamientoPagos = new ProcesamientoPagos();
        this.gestionInventario = new GestionInventario();
        this.envioCorreo = new EnvioCorreo();

    }
    public String procesarPedido(ArrayList<Producto> productos, Usuario usuario){
        if(gestionInventario.reducirInventario(productos)) {
            String valorTotal = procesamientoPagos.procesarPagos(productos);
            String correo = envioCorreo.enviarCorreo(usuario);

            return  valorTotal + "\n" + "Pago procesado con exito, se ha enviado " +"\n" +"una copia al correo: "+ correo;
        } else {
            return "Error procesando el inventario, verifique la cantidad comprada";
        }
    }
}
