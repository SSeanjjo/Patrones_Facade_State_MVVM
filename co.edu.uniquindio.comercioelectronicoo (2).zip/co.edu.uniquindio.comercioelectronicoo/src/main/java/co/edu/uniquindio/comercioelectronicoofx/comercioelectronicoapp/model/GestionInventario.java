package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model;

import java.util.ArrayList;

public class GestionInventario {

    private ArrayList<Producto> inventario;

    public GestionInventario() {
        inventario = new ArrayList<>();
        cargarInventario();
    }

    public boolean reducirInventario(ArrayList<Producto> productos){
        for (int i = 0; i < productos.size(); i++) {
            if(!reducirInventarioPorProducto(productos.get(i))){
                return false;
            }
        }
        return true;
    }

    private boolean reducirInventarioPorProducto(Producto producto){
        for (int i = 0; i < inventario.size(); i++) {
            Producto item = inventario.get(i);
            if(producto.getNombre().equals(item.getNombre())){
                int cantidadActual = item.getCantidad();
                item.setCantidad(cantidadActual- producto.getCantidad());
                return true;
            }
        }
        return false;
    }

    private void cargarInventario(){
        inventario.add(new Producto("TV", 2000, 5));
        inventario.add(new Producto("Camara", 3000, 4));
        inventario.add(new Producto("Celular", 2000, 5));
        inventario.add(new Producto("Computador", 3000, 4));


    }
}
