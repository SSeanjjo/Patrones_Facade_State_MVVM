package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.controller;

import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.factory.ModelFactory;
import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model.Producto;
import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model.Usuario;

import java.util.ArrayList;

public class ComercioElectronicoController {
    ModelFactory modelFactory;

    public ComercioElectronicoController(){
        modelFactory = ModelFactory.getInstance();
    }

    public String procesarPedido(ArrayList<Producto> productos, Usuario usuario){
        return modelFactory.procesarPedido(productos, usuario);
    }




}
