package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model;

public class EnvioCorreo {

    public String enviarCorreo(Usuario usuario){

       String rescorreoCliente = usuario.getEmail();

       return rescorreoCliente + "\n";





    }








}
