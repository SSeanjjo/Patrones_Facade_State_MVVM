package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model;

import java.util.ArrayList;

public class ProcesamientoPagos {



    public String procesarPagos(ArrayList<Producto> productos){

        double contador = 0;

        for (Producto producto: productos){

                double valor = producto.getPrecio() * producto.getCantidad();
                contador = contador + valor;
        }

        return "Valor a pagar: " + contador;
    }

}
