package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.factory;

import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model.ComercioElectronicoFacade;
import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model.Producto;
import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model.Usuario;

import java.util.ArrayList;

public class ModelFactory {

    public static  ModelFactory modelFactory;

    private ComercioElectronicoFacade comercioElectronicoFacade;


    public ModelFactory(){
        comercioElectronicoFacade = new ComercioElectronicoFacade();

    }


    public static ModelFactory getInstance(){
        if (modelFactory == null){
            modelFactory = new ModelFactory();

        }return modelFactory;
    }

    public  String procesarPedido(ArrayList<Producto> productos, Usuario usuario){

        return comercioElectronicoFacade.procesarPedido( productos,usuario);

    }





}
