package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model.Constructor;

import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model.Producto;

public class ProductoBuilder {

    protected String nombre;
    protected double precio;
    protected  int cantidad;

    public ProductoBuilder nombre(String nombre){
        this.nombre = nombre;
        return this;
    }

    public ProductoBuilder precio(double precio){
        this.precio = precio;
        return this;
    }
    public ProductoBuilder cantidad(int cantidad){
        this.cantidad = cantidad;
        return this;
    }

    public Producto build() {

        return new Producto(nombre, precio,cantidad);

    }







}
