package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.viewController;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.controller.ComercioElectronicoController;
import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ComercioElectronicoViewController {

    ComercioElectronicoController comercioElectronicoController;
    GestionInventario gestionInventario;
    EnvioCorreo envioCorreo;
    ProcesamientoPagos procesamientoPagos;
    Producto productoSeleccionado;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button btncomprar;

    @FXML
    private Button cdrCamara;

    @FXML
    private Button cdrCelular;

    @FXML
    private Button cdrComputador;

    @FXML
    private Button crdTelevisor;

    @FXML
    private TextArea areaInformacion;


    @FXML
    private TextField txtCtdadCamara;

    @FXML
    private TextField txtCtdadCelular;

    @FXML
    private TextField txtCtdadComputador;

    @FXML
    private TextField txtCtdadTelevisor;

    private Usuario usuario;

    @FXML
    void btnComprar(ActionEvent event) {

        validarDatos();


    }




    @FXML
    void initialize() {

        comercioElectronicoController = new ComercioElectronicoController();

        limpiarCampos();

        usuario = new Usuario(" Daniel ", "daniel@gmail.com");

        productoSeleccionado = new Producto();
        envioCorreo = new EnvioCorreo();
        procesamientoPagos = new ProcesamientoPagos();


    }

    public void validarDatos(){

        if(txtCtdadCamara.getText().isEmpty() &
                txtCtdadCelular.getText().isEmpty() &
                txtCtdadComputador.getText().isEmpty() &
                txtCtdadTelevisor.getText().isEmpty()){

            areaInformacion.setText("Completa los campos vacios ");

        }else{


           ArrayList<Producto> compras = crearCompra();

           String detalle = "";

           for(Producto producto: compras) {
               if(producto.getCantidad() == 0) continue;
               detalle += producto.getNombre() +": "+ producto.getCantidad() + "\n";
           }

            String respuesta = generarRespuesta(detalle);

            areaInformacion.setText(respuesta) ;
            String información = areaInformacion.getText() + procesoPedido(usuario);
            areaInformacion.setText(información);

            limpiarCampos();

        }
    }


    private String generarRespuesta(String detalle) {
        return "Hola " +usuario.getNombre()+
                "La compra se ha realizado exitosamente, a " +"\n"+
                "continuación se comparte el detalle de la compra: " +
                "\n"+ detalle + "\n";
    }

    private void limpiarCampos() {

        txtCtdadTelevisor.setText("");
        txtCtdadComputador.setText("");
        txtCtdadCelular.setText("");
        txtCtdadCamara.setText("");
    }


    //private String procesarCompra(TextField cmpProducto, Producto producto,Usuario usuario){
       // int cantidad = obtenerCantidad(cmpProducto);
       // if(cantidad > 0){
         //   productoSeleccionado = producto;
          //  procesoPedido(usuario);
           // return producto.getNombre()  ;
        //}
        //return "";
    //}

    private int obtenerCantidad(TextField textField) {
        try {
            return Integer.parseInt(textField.getText());
        } catch (NumberFormatException e) {
            return 0;
        }
    }


    private void mostrarMensaje(String titulo, String header, String contenido, Alert.AlertType alertType) {
        Alert aler = new Alert(alertType);
        aler.setTitle(titulo);
        aler.setHeaderText(header);
        aler.setContentText(contenido);
        aler.showAndWait();
    }

    public String procesoPedido(Usuario usuario){

        if (productoSeleccionado != null) {

            return comercioElectronicoController.procesarPedido(crearCompra(),usuario);



        }else{
            mostrarMensaje("No seleccionado", "seleccione un producto", "Producto no seleccionado", Alert.AlertType.ERROR);
        }
        return null;


    }

    private ArrayList<Producto> crearCompra(){

        Producto tv = new Producto("TV",2000 , obtenerCantidad(txtCtdadTelevisor));
        Producto camara = new Producto("Camara", 3000, obtenerCantidad(txtCtdadCamara));
        Producto computador = new Producto("Computador",2000, obtenerCantidad(txtCtdadComputador));
        Producto celular = new Producto("Celular",3000, obtenerCantidad(txtCtdadCelular));

        ArrayList<Producto> compra = new ArrayList<>();
        compra.add(tv);
        compra.add(camara);
        compra.add(computador);
        compra.add(celular);
        return compra;
    }








}

