package co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model;

import co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.model.Constructor.ProductoBuilder;

import java.util.ArrayList;

public class Producto {
    private String nombre;
    private double precio;
    private int cantidad;

    public Producto() {

    }

    public Producto(String nombre, int cantidad) {
        this.nombre = nombre;
        this.cantidad = cantidad;
    }

    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public static ProductoBuilder builder(){
        return  new ProductoBuilder();
    }

    public double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
