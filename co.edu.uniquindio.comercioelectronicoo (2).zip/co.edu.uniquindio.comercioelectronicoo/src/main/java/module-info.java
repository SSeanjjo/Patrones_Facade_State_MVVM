module co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp {
    requires javafx.controls;
    requires javafx.fxml;


    opens co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp to javafx.fxml;
    exports co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp;

    opens co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.controller;
    exports co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.controller;

    opens co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.viewController;
    exports co.edu.uniquindio.comercioelectronicoofx.comercioelectronicoapp.viewController;
}